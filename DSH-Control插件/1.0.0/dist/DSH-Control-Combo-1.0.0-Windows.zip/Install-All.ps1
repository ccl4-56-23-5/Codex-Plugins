param([string]$DshRoot='D:\DeepSeekHarness')
$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot 'DSH\Install-DSH.ps1') -DshRoot $DshRoot
& (Join-Path $PSScriptRoot 'Codex\Install-Codex.ps1') -DshRoot $DshRoot
Write-Output 'Both plugins installed. Restart DSH if not loaded; reconnect Codex MCP or open a new chat.'
