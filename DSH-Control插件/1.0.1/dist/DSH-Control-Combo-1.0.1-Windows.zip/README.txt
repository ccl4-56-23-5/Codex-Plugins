DSH Control Bridge 1.0.0 + Codex DSH Control 1.0.1
Run Install-All.ps1 in PowerShell. No screenshot recognition.
DSH and Codex source repositories are separate. See each README and SHA256 manifest.
